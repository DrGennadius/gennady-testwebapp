var BigInteger = require('./');
var a = new BigInteger('91823918239182398123');
console.log(a.bitLength());